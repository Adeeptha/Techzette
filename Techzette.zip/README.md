# TechZette

This is a web application which provides the basic functionalities of buying and selling PC products and a special functionality called PC build which gives the user an opportunity to build a custom PC with parts selected from different shops/companies.

Technologies used: Python, Flask, Firebase, HTML, CSS

URL: https://techzettelk.herokuapp.com/

![Picture 1](https://user-images.githubusercontent.com/76934064/159222794-1570d98c-7964-4a39-bfed-ab53a921f3ac.png)
